// POST /api/report   body: { "answers": [20 numbers, each 0 | 33 | 67 | 100] }
//
// The browser never sends a score, only the raw answers. Scoring happens here,
// so nobody can post a fake 100 by editing the page. One report per IP per day.

const V = [0, 33, 67, 100];
const WINDOW = 86400; // seconds

async function redis(cmds) {
  const url = process.env.UPSTASH_REDIS_REST_URL || process.env.KV_REST_API_URL;
  const tok = process.env.UPSTASH_REDIS_REST_TOKEN || process.env.KV_REST_API_TOKEN;
  if (!url || !tok) throw new Error("Redis env vars are missing");
  const r = await fetch(url.replace(/\/$/, "") + "/pipeline", {
    method: "POST",
    headers: { Authorization: "Bearer " + tok, "Content-Type": "application/json" },
    body: JSON.stringify(cmds),
  });
  if (!r.ok) throw new Error("redis " + r.status);
  return (await r.json()).map((x) => x.result);
}

// Same calibration as the page. Percentile against every possible answer pattern.
function erf(z) {
  const s = z < 0 ? -1 : 1; z = Math.abs(z);
  const t = 1 / (1 + 0.3275911 * z);
  return s * (1 - (((((1.061405429 * t - 1.453152027) * t + 1.421413741) * t
    - 0.284496736) * t + 0.254829592) * t) * Math.exp(-z * z));
}
const CDF = (r) => 0.5 * (1 + erf((r - 50) / 15 / Math.SQRT2));
const C0 = CDF(0), C1 = CDF(100);
const cal = (r) => Math.max(0, Math.min(100, ((CDF(r) - C0) / (C1 - C0)) * 100));

function score(a) {
  const m = (x) => x.reduce((p, q) => p + q, 0) / x.length;
  const read = m(a.slice(0, 7)), balls = m(a.slice(7, 15)), degen = m(a.slice(15, 20));
  const dbi = 0.7 * read + 0.2 * balls + 0.1 * degen;
  return { read, balls, degen, dbi, c: cal(dbi), gap: Math.abs(balls - (100 - read)) };
}

async function readBody(req) {
  if (req.body && typeof req.body === "object") return req.body;
  let raw = "";
  for await (const chunk of req) raw += chunk;
  try { return JSON.parse(raw || "{}"); } catch { return {}; }
}

export default async function handler(req, res) {
  res.setHeader("Cache-Control", "no-store");
  if (req.method !== "POST") return res.status(405).json({ error: "POST only" });

  const body = await readBody(req);
  const a = body.answers;
  if (!Array.isArray(a) || a.length !== 20 || !a.every((x) => V.includes(x)))
    return res.status(400).json({ error: "Twenty answers required, each 0, 33, 67 or 100" });

  const ip = String(req.headers["x-forwarded-for"] || "").split(",")[0].trim()
    || req.headers["x-real-ip"] || "unknown";

  try {
    // Claim the slot first. SET NX returns null when the key already exists.
    const [claim] = await redis([["SET", "dbi:rl:" + ip, "1", "NX", "EX", String(WINDOW)]]);
    if (claim === null)
      return res.status(429).json({ error: "One report per day. Come back tomorrow." });

    const s = score(a);
    const bucket = Math.max(0, Math.min(9, Math.floor(s.c / 10)));
    const day = new Date().toISOString().slice(0, 10);
    const dk = "dbi:day:" + day;

    const out = await redis([
      ["HINCRBY", "dbi:agg", "n", "1"],
      ["HINCRBYFLOAT", "dbi:agg", "sD", String(s.dbi)],
      ["HINCRBYFLOAT", "dbi:agg", "sC", String(s.c)],
      ["HINCRBYFLOAT", "dbi:agg", "sR", String(s.read)],
      ["HINCRBYFLOAT", "dbi:agg", "sB", String(s.balls)],
      ["HINCRBYFLOAT", "dbi:agg", "sDe", String(s.degen)],
      ["HINCRBYFLOAT", "dbi:agg", "sG", String(s.gap)],
      ["HINCRBY", "dbi:agg", "h" + bucket, "1"],
      ["HINCRBY", dk, "n", "1"],
      ["HINCRBYFLOAT", dk, "sD", String(s.dbi)],
      ["HINCRBYFLOAT", dk, "sC", String(s.c)],
      ["HINCRBYFLOAT", dk, "sR", String(s.read)],
      ["HINCRBYFLOAT", dk, "sB", String(s.balls)],
      ["EXPIRE", dk, String(86400 * 90)],
    ]);

    res.status(200).json({ no: Number(out[0]) || 1, you: s });
  } catch (e) {
    res.status(503).json({ error: "The index is not reachable right now" });
  }
}
