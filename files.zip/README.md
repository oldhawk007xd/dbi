# Diamond Balls Index

Everything in this folder is the finished website. No build step, no npm install,
no framework. Upload it and it runs.

```
index.html        the whole app
package.json      required, this is what lets the api folder run
og.png            the picture that shows up when the link is posted on X
favicon.svg       the tab icon
api/stats.js      reads the public index
api/report.js     files a report and scores it on the server
api/health.js     open this in a browser when something is wrong
```

Upload all seven. If `package.json` is missing, the api folder fails to start and
no report is ever saved.

---

## Step 1 — Put the files on GitHub (5 minutes)

1. Go to **github.com/new**
2. Repository name: `diamond-balls-index`. Set it to **Public**. Click **Create repository**
3. On the next page click **uploading an existing file**
4. Drag **index.html**, **package.json**, **og.png** and **favicon.svg** into the browser
5. Click **Commit changes**
6. Click **Add file**, then **Create new file**. In the name box type `api/stats.js`
   (typing the slash creates the folder). Paste the contents of `api/stats.js`, then commit
7. Repeat for `api/report.js` and `api/health.js`

The filenames matter. Anything named index inside the api folder gets served at
`/api` rather than at its own address, which is why this route is called `stats`.

## Step 2 — Deploy on Vercel (3 minutes)

1. Go to **vercel.com**, sign in with GitHub
2. **Add New** then **Project**
3. Find `diamond-balls-index` and click **Import**
4. Change nothing. Click **Deploy**
5. You now have a live address like `diamond-balls-index.vercel.app`

At this point the site works, but the gauge shows nothing because there is
nowhere to store the reports yet. That is Step 3.

## Step 3 — Add the database (3 minutes, free)

1. In your Vercel project open the **Storage** tab
2. **Create Database**, pick **Upstash for Redis**, choose the free plan
3. Pick the region closest to you, click **Create**, then **Connect** to the project
4. Go to **Deployments**, click the three dots on the newest one, choose **Redeploy**

Vercel adds `UPSTASH_REDIS_REST_URL` and `UPSTASH_REDIS_REST_TOKEN` for you.
The code reads them automatically.

## Step 4 — Check it (2 minutes)

Open **`yoursite.vercel.app/api/health`** first. It tells you in plain words what
is working and what is not:

- `"ok": true` means the database is connected and reports will save
- `"redisUrlFound": false` means Step 3 did not take, redo it and redeploy
- `"redis": "rejected with status 401"` means the token is stale, disconnect and
  reconnect the database in Vercel Storage, then redeploy
- `"reportsFiled"` is the live count

Then take the test and reload. The counter should read 1.

**If anything is broken you will see a red bar across the top of the site** saying
reports are not being saved. It will never fail quietly.

## Step 5 — Your own domain (optional, about 2 dollars)

1. Buy a domain at **porkbun.com** or **namecheap.com**. A `.xyz` is usually the cheapest
2. In Vercel open **Settings** then **Domains**, add it, and copy the two DNS records
   Vercel shows you into your registrar
3. It goes live in a few minutes

Skip this at first. `vercel.app` works perfectly well and costs nothing.

---

## Before you post it anywhere

**Seed the index.** Send the link privately to thirty or forty traders two days
early. If the first stranger who clicks sees an empty gauge, they leave and they
do not come back. You want a real number sitting there on launch day.

**Post the finding, not the tool.** Nobody reshares "I made a quiz". People
reshare a number. Once you have a few hundred reports, post the gap: the crowd
reads the cycle at X and is positioned as if it were at Y. Screenshot the chart,
put the link underneath.

**Then keep posting it weekly.** The chart is the asset. Anyone can copy a quiz
in an afternoon. Nobody can copy three months of your data.

---

## What it costs

Nothing on this stack, at any traffic level you are likely to see. The index page
is cached at the edge for sixty seconds, so a million visitors cost roughly 1,400
database reads a day rather than a million. There are no paid APIs anywhere in
this project.

## What protects the numbers

- The browser never sends a score. It sends the twenty answers, and the server
  works out the score. Editing the page cannot produce a fake 100
- The answers are checked. Anything that is not twenty values from the set
  0, 33, 67, 100 is rejected
- One report per IP address per day
- If the database is unreachable the site still loads, shows an empty index, and
  tells the user their score was not filed, rather than breaking

That is enough for launch. If it gets big enough to attract someone determined,
add Cloudflare Turnstile to the report endpoint. It is free and takes ten minutes.
